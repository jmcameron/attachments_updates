attachments_for_jevents
=======================

Attachments plugin for JEvents (for Joomla)

This plugin allows users to add attachments to JEvents items in Joomla.


WARNING: This version will only work with Attachments 3.2.2 or later!
         If this version (or later) has not been released, please contact 
	 the Attachments extension Author, Jonathan M. Cameron, to obtain
         a pre-release version at jmcameron@jmcameron.net.

By Jonathan M. Cameron

Created February 20, 2015


For License/Copying information, please see the file LICENSE.txt
