attachments_for_jevents_save
============================

Attachments plugin for JEvents (save) (for Joomla)

The 'JEvents Save Attachments' plugin enables adding attachments to JEvents
events while they are created.

This plugin is a companion plugin for Attachments_for_JEvents.

WARNING: This version will only work with Attachments 3.2.2 or later!
         If this version (or later) has not been released, please contact 
	 the Attachments extension author, Jonathan M. Cameron, to obtain
         a pre-release version at jmcameron@jmcameron.net.

By Jonathan M. Cameron

Created February 25, 2015

For License/Copying information, please see the file LICENSE.txt


INSTALLATION
------------

0. Backup your site!

1. If you do not have Attachments 3.2.2 or later, please contact the author
   and get a copy.  If you have a previous version of Attachments, there is 
   no need to uninstall it first.  Just install the new version over the old
   one.

2. Install the other plugin Attachments_for_JEvents first!

3. Install the Attachments_for_JEvents_Save plugin

4. Enable the Attachments_for_JEvents_Save plugin
